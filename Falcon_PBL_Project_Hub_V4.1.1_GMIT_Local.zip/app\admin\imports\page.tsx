import { redirect } from 'next/navigation';export default function Legacy(){redirect('/hod/imports')}
